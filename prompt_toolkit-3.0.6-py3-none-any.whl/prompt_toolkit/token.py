"""
"""

__all__ = [
    "ZeroWidthEscape",
]

ZeroWidthEscape = "[ZeroWidthEscape]"
